﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CpuRate
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void time_Tick(object sender, EventArgs e)
		{
			int rate = (int)this.performanceCounter.NextValue();

			this.progressBar.Value = rate;
			this.Text = "CPU使用率:" + rate + "%";
		}
	}
}