﻿namespace CpuRate
{
	partial class Form1
	{
		/// <summary>
		/// 必要なデザイナ変数です。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 使用中のリソースをすべてクリーンアップします。
		/// </summary>
		/// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows フォーム デザイナで生成されたコード

		/// <summary>
		/// デザイナ サポートに必要なメソッドです。このメソッドの内容を
		/// コード エディタで変更しないでください。
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.performanceCounter = new System.Diagnostics.PerformanceCounter();
			this.time = new System.Windows.Forms.Timer(this.components);
			this.progressBar = new System.Windows.Forms.ProgressBar();
			((System.ComponentModel.ISupportInitialize)(this.performanceCounter)).BeginInit();
			this.SuspendLayout();
			// 
			// performanceCounter
			// 
			this.performanceCounter.CategoryName = "Processor";
			this.performanceCounter.CounterName = "% Processor Time";
			this.performanceCounter.InstanceName = "_Total";
			// 
			// time
			// 
			this.time.Enabled = true;
			this.time.Interval = 1000;
			this.time.Tick += new System.EventHandler(this.time_Tick);
			// 
			// progressBar
			// 
			this.progressBar.Location = new System.Drawing.Point(12, 12);
			this.progressBar.Name = "progressBar";
			this.progressBar.Size = new System.Drawing.Size(272, 23);
			this.progressBar.TabIndex = 0;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(296, 47);
			this.Controls.Add(this.progressBar);
			this.Name = "Form1";
			this.Text = "CPU使用率";
			this.TopMost = true;
			((System.ComponentModel.ISupportInitialize)(this.performanceCounter)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Diagnostics.PerformanceCounter performanceCounter;
		private System.Windows.Forms.Timer time;
		private System.Windows.Forms.ProgressBar progressBar;
	}
}

