﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AnalogClock
{
	public partial class Form1 : Form
	{
		//真ん中の点
		private readonly Point center = new Point(150, 150);

		public Form1()
		{
			InitializeComponent();

			//ちらつきを防止する魔法のコマンド
			this.DoubleBuffered = true;
		}

		private void timer_Tick(object sender, EventArgs e)
		{
			//画面を更新する
			//下のForm1_Paintを呼んでくれます
			this.Refresh();
		}

		private void Form1_Paint(object sender, PaintEventArgs e)
		{
			//現在の時間
			DateTime dt = DateTime.Now;

			//グラフィックスコンテキストを用意する
			//真っ白な紙を用意するイメージです
			Graphics g = e.Graphics;
			//g.Clear(Color.White);

			//線を描くためのペンを用意する
			Pen hourPen = new Pen(Brushes.Chocolate);
			hourPen.Width = 4;

			Pen minPen = new Pen(Brushes.Chocolate);
			minPen.Width = 4;

			Pen secPen = new Pen(Brushes.Chocolate);
			secPen.Width = 2;

			//針の描画
			g.DrawLine(hourPen, center, calc_endPoint(100, dt.Hour, 12));	//時
			g.DrawLine(minPen, center, calc_endPoint(130, dt.Minute, 60));  //分
			g.DrawLine(secPen, center, calc_endPoint(130, dt.Second, 60));   //秒

			//ペンは使い終わったらしまいましょう。
			hourPen.Dispose();
			minPen.Dispose();
			secPen.Dispose();
		}

		private Point calc_endPoint(int r, int t, int interval)
		{
			//r:半径 t:時間 interval|目盛りの間隔
			double cof = 2 * Math.PI / interval;

			int x = (int)(r * Math.Sin(cof * t)) + center.X;
			int y = (int)(-r * Math.Cos(cof * t)) + center.Y;

			return new Point(x, y);
		}
	}
}